
Contribution Agreement
======================

This repository does accept pull requests (PRs). 

Please ensure your code is of a standard acceptable in the WordPress community and that you have run Lint before 
contributing back.
